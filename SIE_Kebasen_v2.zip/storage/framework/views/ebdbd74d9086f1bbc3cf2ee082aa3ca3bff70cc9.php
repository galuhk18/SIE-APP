

<?php $__env->startSection('title'); ?>
    <title><?php echo e(env('APP_NAME')); ?> | Activity Report</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Laporan Kegiatan
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($activity_report_amount); ?></div>
                    </div>
                    <div class="col-auto">

                        <i class="fas fa-book fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php $__currentLoopData = $activity_report_amount_status; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-xl-3 col-md-6 mb-4">
            <div class="card border-left-primary h-100 py-2">
                <div class="card-body">
                    <div class="row no-gutters align-items-center">
                        <div class="col mr-2">
                            <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                                <?php echo e($activity_report_status[$index]); ?>

                            </div>
                            <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($item); ?></div>
                        </div>
                        <div class="col-auto">

                            <i class="fas fa-book fa-2x text-gray-300"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


</div>
    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between">

                <h6>Laporan Kegiatan</h6>
                <?php if(session()->has('admin_id')): ?>
                <a href="<?php echo e(route('activity.report.create')); ?>" class="btn btn-primary"> <i class="fa fa-plus"></i> Tambah</a>
                <?php endif; ?>
            </div>
            <div>
                <a href="<?php echo e(route('activity.report.export')); ?>" class="btn btn-success"> <i class="fa fa-file-excel"></i>
                    Export</a>
            </div>
            <hr>
            <div class="table-responsive">
                <table class="table" id="dataTable">
                    <thead>
                        <tr>
                            <th class="text-center">Tanggal Kegiatan</th>
                            <th class="text-center">Nama Organisasi</th>
                            <th class="text-center">Keterangan</th>
                            <th class="text-center">Penanggung Jawab</th>
                            <th class="text-center">Dokumentasi</th>
                            <th class="text-center">Status</th>
                            <th class="text-center">Created</th>
                            <th class="text-center">Updated</th>
                            <th class="text-center"><i class="fa fa-cogs"></i></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $activity_report; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        <tr>
                            <td class="text-center"><?php echo e($item->date_of_activity); ?></td>
                            <td class="text-center"><?php echo e($item->organization_name); ?></td>
                            <td class="text-center"><?php echo e($item->information); ?></td>
                            <td class="text-center"><?php echo e($item->person_responsible); ?></td>
                            <td class="text-center">
                                <img src="<?php echo e(asset($item->documentation)); ?>" width="100px" alt="documentaion">
                            </td>
                            
                            <td class="text-center"><?php echo e($activity_report_status[$item->status]); ?></td>
                            <td class="text-center"><?php echo e($item->created_at); ?></td>
                            <td class="text-center"><?php echo e($item->updated_at); ?></td>
                            <td class="text-center">
                                <a href="<?php echo e(route('activity.report.edit', ['id' => $item->id])); ?>" class="btn-info btn-sm"><i class="fa fa-edit"></i></a>
                                <a href="<?php echo e(route('activity.report.destroy',['id' => $item->id])); ?>" class="btn-danger btn-sm delete-confirm"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
    $('#dataTable').DataTable();
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.base_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\SIE_Kebasen\resources\views/admin/activity_report/index.blade.php ENDPATH**/ ?>