
<?php $__env->startSection('title'); ?>
<title><?php echo e(env('APP_NAME')); ?></title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="jumbotron jumbotron-full">
    <div class="container text-center box-hello">
      <h1 class="display-4">Selamat Datang di</h1>
      <p class="lead">SISTEM INFORMASI EKSEKUTIF LAPORAN DESA KEBASEN</p>
    </div>
  </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.base_home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\SIE_Kebasen\resources\views/home.blade.php ENDPATH**/ ?>