<footer class="sticky-footer bg-white">
    <div class="container my-auto">
        <div class="copyright text-center my-auto">
            <span>Copyright &copy; <?php echo e(env('APP_NAME')); ?> <?php echo e(date('Y')); ?></span>
        </div>
    </div>
</footer>
<?php /**PATH D:\laragon\www\SIE_Kebasen\resources\views/template/footer.blade.php ENDPATH**/ ?>