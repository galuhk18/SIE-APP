
<?php $__env->startSection('title'); ?>
<title><?php echo e(env('APP_NAME')); ?> | Admin Login</title>    
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">

            <div class="col-xl-10 col-lg-12 col-md-9">

                <div class="card o-hidden border-0 shadow-lg my-5">
                    <div class="card-body p-0">
                        <!-- Nested Row within Card Body -->
                        <div class="row">
                            <div class="col-lg-6 d-none d-lg-block bg-side">
                                
                                <div class="text-white d-flex align-items-center justify-content-center" style="height: 500px;">
                                   <img src="<?php echo e(asset('assets/img/logo-bms.png')); ?>" width="100px" alt="">
                                </div>
                            </div>
                            <div class="col-lg-6">
                                <div class="p-5">
                                    <div class="text-center">
                                        <h2 class="font-weight-bold text-gray-900">SISTEM INFORMASI EKSEKUTIF LAPORAN DESA KEBASEN</h2>
                                        <h6 class="">Login Admin</h6>
                                    </div>
                                    <hr>
                                    <form class="user" action="<?php echo e(route('auth.admin.login.validation')); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="form-group">
                                            <input type="text" name="email" class="form-control form-control-user" id="exampleInputEmail" aria-describedby="emailHelp" placeholder="Enter Email Address...">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger">
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <div class="form-group">
                                            <input type="password" name="password" class="form-control form-control-user" id="exampleInputPassword" placeholder="Password">
                                            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger">
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        
                                        <button type="submit" class="btn btn-info btn-user btn-block">
                                            Login
                                        </button>
                                       
                                        <a href="<?php echo e(route('index')); ?>" class="btn btn-secondary btn-user btn-block">Kembali ke Halaman Utama</a>
                                        
                                    </form>
                                    <hr>
                                  
                                    <div class="text-center">
                                        <p class="small" ><i class="fa fa-copyright"></i> <?php echo e(env('APP_NAME').' '.date('Y')); ?></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\SIE_Kebasen\resources\views/auth/admin-login.blade.php ENDPATH**/ ?>