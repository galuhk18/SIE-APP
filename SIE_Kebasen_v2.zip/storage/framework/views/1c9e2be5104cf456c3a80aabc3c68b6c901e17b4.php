

<?php $__env->startSection('title'); ?>
    <title><?php echo e(env('APP_NAME')); ?> | User Admin</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
           
            <div class="text-center">

                <h4>Profile</h4>
            </div>
            <hr>
            <div class="row">
                <div class="col-lg-6 mx-auto">
                    <div class="text-center">

                        <i class="fa fa-user-circle" style="font-size: 200px;"></i>
                    </div>
                    <div class="table-responsive mt-2">
                         <table class="table table-hover">
                             <tr>
                                 <th>Nama</th>
                                 <td>:</td>
                                 <td><?php echo e($profile->name); ?></td>
                             </tr>
                             <tr>
                                <th>Email</th>
                                <td>:</td>
                                <td><?php echo e($profile->email); ?></td>
                             </tr>
                            <tr>
                                <th>Username</th>
                                <td>:</td>
                                <td><?php echo e($profile->username); ?></td>
                            </tr>
                            <tr>
                                <th>Status</th>
                                <td>:</td>
                                <td><?php echo e("Admin"); ?></td>
                            </tr>
                         </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.base_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\SIE_Kebasen\resources\views/admin/user-admin/profile.blade.php ENDPATH**/ ?>