

<?php $__env->startSection('title'); ?>
    <title><?php echo e(env('APP_NAME')); ?> | User Admin</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between">

                <h6>Data Admin</h6>
                <a href="<?php echo e(route('user.admin.create')); ?>" class="btn btn-primary"> <i class="fa fa-plus"></i> Add New</a>
            </div>
            <hr>
            <div class="table-responsive">
                <table class="table" id="dataTable">
                    <thead>
                        <tr>
                            <th class="text-center">Name</th>
                            <th class="text-center">Username</th>
                            <th class="text-center">Email</th>
                            <th class="text-center">Address</th>
                            <th class="text-center">Phone Number</th>
                            <th class="text-center">Created</th>
                            <th class="text-center">Updated</th>
                            <th class="text-center"><i class="fa fa-cogs"></i></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $admin; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        <tr>
                            <td class="text-center"><?php echo e($item->name); ?></td>
                            <td class="text-center"><?php echo e($item->username); ?></td>
                            <td class="text-center"><?php echo e($item->email); ?></td>
                            <td class="text-center"><?php echo e($item->address); ?></td>
                            <td class="text-center"><?php echo e($item->phone_number); ?></td>
                            <td class="text-center"><?php echo e($item->created_at); ?></td>
                            <td class="text-center"><?php echo e($item->updated_at); ?></td>
                            <td class="text-center">
                                <a href="<?php echo e(route('user.admin.edit', ['id' => $item->id])); ?>" class="btn-info btn-sm"><i class="fa fa-edit"></i></a>
                                <a href="<?php echo e(route('user.admin.pass', ['id' => $item->id])); ?>" class="btn-warning btn-sm"><i class="fa fa-lock"></i></a>
                                <?php if(session('admin_id') !== $item->id): ?>
                                <a href="<?php echo e(route('user.admin.destroy',['id' => $item->id])); ?>" class="btn-danger btn-sm delete-confirm"><i class="fa fa-trash"></i></a>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
    $('#dataTable').DataTable();
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.base_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\SIE_Kebasen\resources\views/admin/user-admin/index.blade.php ENDPATH**/ ?>