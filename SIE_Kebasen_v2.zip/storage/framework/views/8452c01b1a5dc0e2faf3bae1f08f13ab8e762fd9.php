

<?php $__env->startSection('title'); ?>
    <title><?php echo e(env('APP_NAME')); ?> | Activity</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-xl-3 col-md-6 mb-4">
        <div class="card border-left-primary h-100 py-2">
            <div class="card-body">
                <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                        <div class="text-xs font-weight-bold text-primary text-uppercase mb-1">
                            Laporan Jadwal Kegiatan
                        </div>
                        <div class="h5 mb-0 font-weight-bold text-gray-800"><?php echo e($activity_amount); ?></div>
                    </div>
                    <div class="col-auto">
                        
                        <i class="fas fa-calendar fa-2x text-gray-300"></i>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
    <div class="card">
        <div class="card-body">
            <div class="d-flex justify-content-between">

                <h6>Jadwal Kegiatan</h6>
                <?php if(session()->has('admin_id')): ?>
                <a href="<?php echo e(route('activity.create')); ?>" class="btn btn-primary"> <i class="fa fa-plus"></i> Tambah</a>
                <?php endif; ?>
            </div>
            <div>
                <a href="<?php echo e(route('activity.export')); ?>" class="btn btn-success"> <i
                        class="fa fa-file-excel"></i> Export</a>
                <?php if(session()->has('admin_id')): ?>
    
    
                    <!-- Button trigger modal -->
                    <button type="button" class="btn btn-outline-success" data-toggle="modal" data-target="#importModal">
                        <i class="fa fa-file-excel"></i> Import
                    </button>
    
                    <!-- Modal -->
                    <div class="modal fade" id="importModal" tabindex="-1" aria-labelledby="exampleModalLabel"
                        aria-hidden="true">
                        <div class="modal-dialog">
                            <div class="modal-content">
                                <div class="modal-header bg-success">
                                    <h5 class="modal-title text-white" id="exampleModalLabel">Import</h5>
                                    <button type="button" class="close text-white" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <form action="<?php echo e(route('activity.import')); ?>" method="post"
                                    enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="modal-body">
                                        <div class="form-group">
                                            <label for="file">Upload File Form Excel</label>
    
                                            <input type="file" name="file" class="form-control">
                                            <small class="text-danger">*) Format Date of activity : 1997-05-11</small>
                                            <?php $__errorArgs = ['file'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger">
                                                    <?php echo e($message); ?>

                                                </div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                        <a href="<?php echo e(route('activity.form.export')); ?>"
                                            class="btn-link text-success mt-5">Download Form</a>
                                    </div>
                                    <div class="modal-footer">
    
                                        <button type="submit" class="btn btn-success"> <i class="fa fa-upload"></i>
                                            Upload</button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            <hr>
            <div class="table-responsive">
                <table class="table" id="dataTable">
                    <thead>
                        <tr>
                            <th class="text-center">Nama Kegiatan</th>
                            <th class="text-center">Tanggal Kegiatan</th>
                            <th class="text-center">Tempat</th>
                            <th class="text-center">Keterangan</th>
                            <th class="text-center">Created</th>
                            <th class="text-center">Updated</th>
                            <th class="text-center"><i class="fa fa-cogs"></i></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $activity; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                        <tr>
                            <td class="text-center"><?php echo e($item->name); ?></td>
                            <td class="text-center"><?php echo e($item->date_of_activity); ?></td>
                            <td class="text-center"><?php echo e($item->address); ?></td>
                            <td class="text-center"><?php echo e($item->information); ?></td>
                            <td class="text-center"><?php echo e($item->created_at); ?></td>
                            <td class="text-center"><?php echo e($item->updated_at); ?></td>
                            <td class="text-center">
                                <a href="<?php echo e(route('activity.edit', ['id' => $item->id])); ?>" class="btn-info btn-sm"><i class="fa fa-edit"></i></a>
                                <a href="<?php echo e(route('activity.destroy',['id' => $item->id])); ?>" class="btn-danger btn-sm delete-confirm"><i class="fa fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('script'); ?>
<script>
    $(document).ready(function() {
    $('#dataTable').DataTable();
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('template.base_admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\SIE_Kebasen\resources\views/admin/activity/index.blade.php ENDPATH**/ ?>