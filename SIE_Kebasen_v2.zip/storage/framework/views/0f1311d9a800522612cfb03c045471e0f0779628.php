<nav class="navbar navbar-expand navbar-dark bg-light topbar mb-4 static-top shadow">

    <!-- Sidebar Toggle (Topbar) -->
    <button id="sidebarToggleTop" class="btn btn-link text-dark  rounded-circle mr-3">
        <i class="fa fa-bars"></i>
    </button>

    <!-- Topbar Navbar -->
    <ul class="navbar-nav ml-auto">
        <!-- Nav Item - User Information -->
        <li class="nav-item dropdown no-arrow">
            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                
                <?php if(session()->has('admin_id')): ?>
                    <?php
                        $user_admin = DB::table('admin')->where('id', session('admin_id'))->first();
                    ?>
                    <span class="mr-2 d-none d-lg-inline text-dark">Hi, <?php echo e($user_admin->name); ?> </span>
                <?php endif; ?>
                
                <?php if(session()->has('executive_id')): ?>
                    <?php
                        $user_executive = DB::table('executive')->where('id', session('executive_id'))->first();
                    ?>
                    <span class="mr-2 d-none d-lg-inline text-dark">Hi, <?php echo e($user_executive->name); ?> </span>
                <?php endif; ?>
               
                <i class="fa fa-user text-dark"></i>
            </a>
            <!-- Dropdown - User Information -->
            <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in"
                aria-labelledby="userDropdown">
                <a class="dropdown-item" href="#">
                    <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                    <?php if(session()->has('admin_id')): ?>
                        <?php echo e($user_admin->username); ?>

                    <?php endif; ?>

                    <?php if(session()->has('executive_id')): ?>
                        <?php echo e($user_executive->username); ?>

                    <?php endif; ?>
                </a>



                <div class="dropdown-divider"></div>

                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#logoutModal">
                    <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                    Logout
                </a>
            </div>
        </li>
    </ul>
</nav>
<?php /**PATH D:\laragon\www\SIE_Kebasen\resources\views/template/navbar_admin.blade.php ENDPATH**/ ?>